CREATE VIEW w_vo AS
  SELECT
    `meeting`.`meeting_arrangement`.`row_id`            AS `row_id`,
    `meeting`.`meeting_arrangement`.`start_time`        AS `start_time`,
    `meeting`.`meeting_arrangement`.`apply_date`        AS `apply_date`,
    `meeting`.`meeting_arrangement`.`call_leader_name`  AS `call_leader_name`,
    `meeting`.`meeting_arrangement`.`call_orgs_name`    AS `call_orgs_name`,
    `meeting`.`meeting_arrangement`.`use_org_name`      AS `use_org_name`,
    `meeting`.`meeting_arrangement`.`end_time`          AS `end_time`,
    `meeting`.`file_record`.`file_name`                 AS `file_name`,
    `meeting`.`meeting_arrangement`.`meeting_room_name` AS `meeting_room_name`,
    `meeting`.`meeting_arrangement`.`call_users_name`   AS `call_users_name`,
    `meeting`.`meeting_arrangement`.`title`             AS `title`,
    `meeting`.`meeting_arrangement`.`week`              AS `week`,
    `meeting`.`meeting_arrangement`.`year`              AS `year`,
    `meeting`.`meeting_arrangement`.`ext2`              AS `ext2`,
    `meeting`.`meeting_arrangement`.`auditor_name`      AS `auditor_name`,
    `meeting`.`meeting_arrangement`.`auditor_id`        AS `auditor_id`,
    `meeting`.`meeting_arrangement`.`day_of_week`       AS `day_of_week`
  FROM (`meeting`.`meeting_arrangement`
    LEFT JOIN `meeting`.`file_record` ON ((convert(`meeting`.`meeting_arrangement`.`row_id` USING utf8mb4) =
                                           `meeting`.`file_record`.`arrangement_id`)));
