CREATE VIEW v_org_role_user AS
  SELECT
    concat(`r`.`role_id`, `u`.`user_id`) AS `v_role_user_key`,
    `u`.`row_id`                         AS `user_key`,
    `u`.`user_name`                      AS `user_name`,
    `u`.`user_show_name`                 AS `user_show_name`,
    `u`.`user_en_name`                   AS `user_en_name`,
    `u`.`user_id`                        AS `user_id`,
    `u`.`create_time`                    AS `create_time`,
    `u`.`create_user_id`                 AS `create_user_id`,
    `u`.`data_status`                    AS `data_status`,
    `u`.`data_order`                     AS `data_order`,
    `u`.`user_mobile_num`                AS `user_mobile_num`,
    `u`.`user_sex`                       AS `user_sex`,
    `u`.`user_type`                      AS `user_type`,
    `r`.`row_id`                         AS `role_key`,
    `r`.`role_name`                      AS `role_name`,
    `r`.`role_id`                        AS `role_id`,
    `r`.`role_intro`                     AS `role_intro`,
    `r`.`create_time`                    AS `r_create_time`,
    `r`.`create_user_id`                 AS `r_create_user_id`,
    `r`.`data_order`                     AS `r_data_order`,
    `r`.`role_type`                      AS `role_type`,
    `ru`.`rl_type`                       AS `rl_type`,
    `ru`.`row_id`                        AS `rhu_id`
  FROM ((`meeting`.`gx_sys_user_org_role` `r`
    JOIN `meeting`.`gx_sys_user` `u`) JOIN `meeting`.`gx_sys_org_role_has_user` `ru`)
  WHERE ((`r`.`role_id` = `ru`.`role_id`) AND (`u`.`user_id` = `ru`.`user_id`));
