create definer = njdtweb@`%` view v_sys_dic as
select concat(`d`.`ROW_ID`, '_', `i`.`ROW_ID`) AS `v_sys_dic_key`,
       `i`.`DIC_FUNCTION_NAME`                 AS `index_dic_name`,
       `i`.`DIC_FUNCTION_ID`                   AS `index_dic_id`,
       `i`.`DIC_FUNCTION_DEC`                  AS `index_dic_desc`,
       `d`.`DIC_NAME`                          AS `record_dic_name`,
       `d`.`DIC_ID`                            AS `record_dic_id`,
       `d`.`DIC_SHOW_VAL`                      AS `DIC_SHOW_VAL`,
       `d`.`DIC_VALUE`                         AS `DIC_VALUE`,
       `d`.`DIC_TYPE`                          AS `DIC_TYPE`,
       `d`.`ORDER_NUM`                         AS `ORDER_NUM`,
       `d`.`max_status`                        AS `max_status`,
       `d`.`max_id`                            AS `max_id`
from (`meeting`.`gx_sys_dic_index` `i`
         join `meeting`.`gx_sys_dic_record` `d`)
where (`i`.`ROW_ID` = `d`.`TABLE_ID`);

-- comment on column v_sys_dic.index_dic_name not supported: 索引名称

-- comment on column v_sys_dic.index_dic_id not supported: 索引功能ID

-- comment on column v_sys_dic.index_dic_desc not supported: 索引显示内容

-- comment on column v_sys_dic.max_status not supported: 是否启用最大值配置（1启用，0否）

-- comment on column v_sys_dic.max_id not supported: 最大值的ID

