create definer = njdtweb@`%` view v_role_user as
select concat(`r`.`role_id`, `u`.`user_id`) AS `v_role_user_key`,
       `u`.`row_id`                         AS `user_key`,
       `u`.`user_name`                      AS `user_name`,
       `u`.`user_show_name`                 AS `user_show_name`,
       `u`.`user_en_name`                   AS `user_en_name`,
       `u`.`user_id`                        AS `user_id`,
       `u`.`create_time`                    AS `create_time`,
       `u`.`create_user_id`                 AS `create_user_id`,
       `u`.`modify_time`                    AS `modify_time`,
       `u`.`modify_user_id`                 AS `modify_user_id`,
       `u`.`data_status`                    AS `data_status`,
       `u`.`data_order`                     AS `data_order`,
       `u`.`user_mobile_num`                AS `user_mobile_num`,
       `u`.`user_sex`                       AS `user_sex`,
       `u`.`user_type`                      AS `user_type`,
       `r`.`row_id`                         AS `role_key`,
       `r`.`role_name`                      AS `role_name`,
       `r`.`role_id`                        AS `role_id`,
       `r`.`role_intro`                     AS `role_intro`,
       `r`.`create_time`                    AS `r_create_time`,
       `r`.`create_user_id`                 AS `r_create_user_id`,
       `r`.`modify_time`                    AS `r_modify_time`,
       `r`.`modify_user_id`                 AS `r_modify_user_id`,
       `r`.`data_status`                    AS `r_data_status`,
       `r`.`data_order`                     AS `r_data_order`,
       `r`.`parent_role_id`                 AS `parent_role_id`,
       `r`.`parent_role_name`               AS `parent_role_name`,
       `r`.`role_type`                      AS `role_type`,
       `ru`.`rl_type`                       AS `rl_type`,
       `ru`.`row_id`                        AS `rhu_id`
from ((`meeting`.`gx_sys_role` `r` join `meeting`.`gx_sys_user` `u`)
         join `meeting`.`gx_sys_role_has_user` `ru`)
where ((`r`.`role_id` = `ru`.`role_id`) and (`u`.`user_id` = `ru`.`user_id`));

-- comment on column v_role_user.user_key not supported: 主键

-- comment on column v_role_user.user_name not supported: 用户名称

-- comment on column v_role_user.user_show_name not supported: 用户别名

-- comment on column v_role_user.user_en_name not supported: 用户英文名称

-- comment on column v_role_user.user_id not supported: 用户帐号

-- comment on column v_role_user.create_time not supported: 创建时间

-- comment on column v_role_user.create_user_id not supported: 创建者ID

-- comment on column v_role_user.modify_time not supported: 修改时间

-- comment on column v_role_user.modify_user_id not supported: 修改人ID

-- comment on column v_role_user.data_status not supported: 状态

-- comment on column v_role_user.data_order not supported: 排序

-- comment on column v_role_user.user_mobile_num not supported: 手机号

-- comment on column v_role_user.user_sex not supported: 性别

-- comment on column v_role_user.user_type not supported: 用户类型

-- comment on column v_role_user.role_key not supported: 主键

-- comment on column v_role_user.role_name not supported: 角色名称

-- comment on column v_role_user.role_id not supported: 角色ID

-- comment on column v_role_user.role_intro not supported: 角色说明

-- comment on column v_role_user.r_create_time not supported: 创建时间

-- comment on column v_role_user.r_create_user_id not supported: 创建者ID

-- comment on column v_role_user.r_modify_time not supported: 修改时间

-- comment on column v_role_user.r_modify_user_id not supported: 修改人ID

-- comment on column v_role_user.r_data_status not supported: 状态

-- comment on column v_role_user.r_data_order not supported: 排序

-- comment on column v_role_user.parent_role_id not supported: 父角色ID

-- comment on column v_role_user.parent_role_name not supported: 父角色名称

-- comment on column v_role_user.role_type not supported: 角色类别

-- comment on column v_role_user.rl_type not supported: 关系类别

-- comment on column v_role_user.rhu_id not supported: 主键

